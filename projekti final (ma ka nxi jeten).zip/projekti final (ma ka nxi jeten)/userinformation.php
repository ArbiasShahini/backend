<?php

$connection = mysqli_connect('localhost', 'root');

mysqli_select_db($connection, "arbiasdata");

$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];

$query = "INSERT INTO `userinfodata`(`name`,`email`,`message`) VALUES ('$name','$email','$message') ";

mysqli_query($connection, $query);

echo "MESSAGE IS SENT";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // handle form submission
    // ...

    // redirect back to index.php
    header('Location: index.php');
    exit;
}

?>
