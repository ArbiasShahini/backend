<!-- login.php -->
<?php
// admin password
$adminPassword = 'your_admin_password';

// Check if password is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = $_POST['password'];

    // Validate password
    if ($password === $adminPassword) {
        // Start the session and store authentication flag
        session_start();
        $_SESSION['authenticated'] = true;
        header('Location: admin.php');
        exit;
    } else {
        // Show error message for invalid password
        echo 'Invalid password';
    }
}
?>

<!-- admin.php -->
<?php
// Check if admin is authenticated
session_start();
if (!isset($_SESSION['authenticated'])) {
    header('Location: login.html');
    exit;
}

// Retrieve comments from the database
// Use your own database connection details
$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];
$dbname = 'arbiasdata';

// Create a database connection
$conn = new mysqli($name, $email, $message, $dbname);
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

// Fetch all comments from the database
$sql = 'SELECT * FROM comments';
$result = $conn->query($sql);

// Display comments
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo '<div class="comment">';
        echo '<h3>' . $row['name'] . '</h3>';
        echo '<p>' . $row['email'] . '</p>';
        echo '<p>' . $row['comment'] . '</p>';
        echo '</div>';
    }
} else {
    echo 'No comments found.';
}

// Close the database connection
$conn->close();
?>
