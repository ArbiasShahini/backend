// Get the contact button element
var contactBtn = document.getElementById("contact-btn");

// Get the contact form element
var contactForm = document.getElementById("contact-form");

// Add an event listener to the contact button
contactBtn.addEventListener("click", function() {
   // Scroll to the contact form
   contactForm.scrollIntoView();

});
