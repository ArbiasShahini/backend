<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Dynamic Website</title>
    <link rel="stylesheet" href="css/style.css" />
</head>

<body>
    <header class="main">
        <nav>
            <a href="#" class="logo">
                <img src="images/logo1.png" />
            </a>

            <ul class="menu">
                <li><a href="#" class="active">Home</a></li>
                <li><a
                        href="https://docs.google.com/presentation/d/1xfNf1aAiTcnrqU_MpR1Ic-Uzpdt0x0CjhXAuRm85w5I/edit?usp=sharing">Features</a>
                </li>
                <li><a href="about.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="admin.php">Admin</li>
            </ul>
        </nav>
        <div class="main-heading">
            <h1>Create Prespectives With Virtual Reality</h1>
            <p>Virtual reality (VR) technology offers endless possibilities for creating immersive experiences that
                transport users to new environments and offer unique perspectives.
                With advanced graphics and sensory technology, VR has the potential to revolutionize the way we interact
                with digital content,
                and we can expect to see even more exciting applications in the future. </p>
        </div>
    </header>

    <section class="features">
        <div class="feature-container">

            <div class="feature-box">
                <div class="f-img">
                    <img src="images/info-icon1.png" />
                </div>
                <div class="f-text">
                    <h4>Web Development</h4>
                    <p>Lorem ipsum dolor sit amet.</p>
                    <a href="#" class="main-btn">Check</a>
                </div>
            </div>

            <div class="feature-box">
                <div class="f-img">
                    <img src="images/info-icon2.png" />
                </div>
                <div class="f-text">
                    <h4>UL/UX</h4>
                    <p>Lorem ipsum dolor sit amet.</p>
                    <a href="#" class="main-btn">Check</a>
                </div>
            </div>

            <div class="feature-box">
                <div class="f-img">
                    <img src="images/info-icon3.png" />
                </div>
                <div class="f-text">
                    <h4>Virtual reality</h4>
                    <p>Lorem ipsum dolor sit amet.</p>
                    <a href="#" class="main-btn">Check</a>
                </div>
            </div>
        </div>
    </section>

    <section class="about">
        <div class="about-img">
            <img src="images/about.png">
        </div>
        <div class="about-text">
            <h2>Start Tracking Your Statistics</h2>
            <p>With our virtual world, you can easily track your statistics and make data-driven decisions to achieve
                your goals.
                Join now to unlock your full potential and experience the power of advanced analytics.</p>
        </div>
    </section>
    <!-- code -->
    <footer class="footer">
        <div class="waves">
            <div class="wave" id="wave1"></div>
            <div class="wave" id="wave2"></div>
            <div class="wave" id="wave3"></div>
            <div class="wave" id="wave4"></div>
        </div>
        <ul class="social-icon">
            <li class="social-icon__item"><a class="social-icon__link"
                    href="https://www.facebook.com/profile.php?id=100087247134294">
                    <ion-icon name="logo-facebook"></ion-icon>
                </a></li>
            <li class="social-icon__item"><a class="social-icon__link"
                    href="https://www.linkedin.com/in/arbias-shahini-28087b235/">
                    <ion-icon name="logo-linkedin"></ion-icon>
                </a></li>
            <li class="social-icon__item"><a class="social-icon__link" href="https://www.instagram.com/arbiasshahinii/">
                    <ion-icon name="logo-instagram"></ion-icon>
                </a></li>
        </ul>
        <ul class="menu">
            <li class="menu__item"><a class="menu__link" href="index.php">Home</a></li>
            <li class="menu__item"><a class="menu__link" href="about.php">About</a></li>
            <li class="menu__item"><a class="menu__link"
                    href="https://docs.google.com/presentation/d/1xfNf1aAiTcnrqU_MpR1Ic-Uzpdt0x0CjhXAuRm85w5I/edit?usp=sharing">Featuress</a>
            </li>
            <li class="menu__item"><a class="menu__link" href="contact.php">Contact</a></li>

        </ul>
        <p>&copy;2023 ELDAS | All Rights Reserved</p>
    </footer>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

    <!-- code -->


    <script src="main.js"></script>
</body>

</html>