<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Dynamic Website</title>
    <link rel="stylesheet" href="css/about.css" />
</head>

<body>
    <header class="main">
        <nav>
            <a href="#" class="logo">
                <img src="images/logo1.png" />
            </a>

            <ul class="menu">
                <li><a href="index.php" class="active">Home</a></li>
                <li><a
                        href="https://docs.google.com/presentation/d/1xfNf1aAiTcnrqU_MpR1Ic-Uzpdt0x0CjhXAuRm85w5I/edit?usp=sharing">Features</a>
                </li>
                <li><a href="about.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </nav>
        <div class="main-heading">
            <h1>About our Virtual World </h1>
            <p> </p>
            <a class="main-btn" href="contact.php">Contact</a>
        </div>
    </header>

    <section class="features">
        <div class="feature-container">


            <div class="feature-box">
                <div class="founder">
                    <img src="images/Arbias Shahini.JPG" alt="Founder Name">
                    <h2>Arbias Shahini</h2>
                    <p>CEO</p>
                    <p>Arbias Shahini, 16, owner of Eldas Company - a virtual reality firm pushing boundaries with
                        innovation and technology. </p>
                </div>
            </div>

    </section>
    <!-- chart -->

    <section class="chart">
        <div class="bar-chart primary" data-total="95" animated>
            <span class="bar-chart--inner" style="width:95%;"></span>
            <span class="bar-chart--text">95% Front End Development</span>
        </div>

        <div class="bar-chart secondary" data-total="35" animated>
            <span class="bar-chart--inner" style="width:35%;"></span>
            <span class="bar-chart--text">35% UL/UX</span>
        </div>

        <div class="bar-chart tertiary" data-total="80" animated>
            <span class="bar-chart--inner" style="width:80%;"></span>
            <span class="bar-chart--text">80% VR</span>
        </div>
    </section>
    <!-- chaty -->

    <section class="about">
        <div class="about-img">
            <img src="images/about.JPG">
        </div>
        <div class="about-text">
            <h2>Experience Immersive Virtual Reality with Eldas</h2>
            <p>
Eldas is a virtual reality website that offers a wide range of virtual servers and other virtual products for users to explore and interact with. 
With advanced technology and cutting-edge graphics, Eldas creates immersive experiences that transport users to new and exciting environments. 
Whether it's exploring a distant planet, diving into the depths of the ocean, or simply interacting with digital objects in a new way, 
Eldas offers a powerful platform for engaging with the world of virtual reality. With a focus on innovation and user experience, 
Eldas is helping to shape the future of digital media and transform the way we interact with technology.</p>
        </div>
    </section>
<!-- code -->
<footer class="footer">
    <div class="waves">
      <div class="wave" id="wave1"></div>
      <div class="wave" id="wave2"></div>
      <div class="wave" id="wave3"></div>
      <div class="wave" id="wave4"></div>
    </div>
    <ul class="social-icon">
            <li class="social-icon__item"><a class="social-icon__link"
                    href="https://www.facebook.com/profile.php?id=100087247134294">
                    <ion-icon name="logo-facebook"></ion-icon>
                </a></li>
            <li class="social-icon__item"><a class="social-icon__link"
                    href="https://www.linkedin.com/in/arbias-shahini-28087b235/">
                    <ion-icon name="logo-linkedin"></ion-icon>
                </a></li>
            <li class="social-icon__item"><a class="social-icon__link" href="https://www.instagram.com/arbiasshahinii/">
                    <ion-icon name="logo-instagram"></ion-icon>
                </a></li>
        </ul>
    <ul class="menu">
      <li class="menu__item"><a class="menu__link" href="index.php">Home</a></li>
      <li class="menu__item"><a class="menu__link" href="about.php">About</a></li>
      <li class="menu__item"><a class="menu__link" href="https://docs.google.com/presentation/d/1xfNf1aAiTcnrqU_MpR1Ic-Uzpdt0x0CjhXAuRm85w5I/edit?usp=sharing">Featuress</a></li>
      <li class="menu__item"><a class="menu__link" href="contact.php">Contact</a></li>

    </ul>
    <p>&copy;2023 ELDAS | All Rights Reserved</p>
  </footer>
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

<!-- code -->
    <script src="about.js"></script>
</body>

</html>